const events = {};

const pubsub = {
    publish: (eventName, data) => {
        if (!events[eventName]) return;
        events[eventName].forEach(callback => {
            try {
                callback(data);
            } catch (error) {
                console.error(error);
            }
        });
    },
    subscribe: (eventName, callback) => {
        if (!events[eventName]) {
            events[eventName] = [];
        }
        events[eventName].push(callback);
    }
};

export default pubsub;
