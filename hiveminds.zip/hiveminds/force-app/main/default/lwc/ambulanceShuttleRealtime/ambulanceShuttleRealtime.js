import { api, LightningElement, track } from 'lwc';
import getLatestShuttle from '@salesforce/apex/AmbulanceShuttleController.getLatestShuttle';
import updateShuttleStatus from '@salesforce/apex/AmbulanceShuttleController.updateShuttleStatus';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import AmbulanceGifResource from '@salesforce/resourceUrl/AmbulanceGif';
import createPatientRecord from '@salesforce/apex/AmbulanceShuttleController.createPatientRecord';

export default class LatestAmbulance extends LightningElement {
    @track vehicleName = 'Loading...';
    @track noteForDriver = '';
    @track fromLocation = '';
    @track toLocation = '';
    @track shuttleId;
    @track hideButtonsAndNote = false;
    @track showAnimation = false;
    @track showWallpaper = false;
    @track countdown = 0;
    @track ambulanceGifUrl = AmbulanceGifResource;
    @track showFirstAmbulance = true;
    @track showSecondAmbulance = false;
    @track showActionButtons = false;
    @track showPatientForm = false;
    @track isSubmitting = false;
    @track showThankYou = false;
    @track smartRouteText = '';
    @track showSmartRoute = false;

    loopInterval;  

    connectedCallback() {
        this.startAmbulanceLoop();
        this.fetchLatest(); 

        if (navigator.vibrate) {
            navigator.vibrate(200);
        }
    }

    disconnectedCallback() {
        clearInterval(this.loopInterval); 
    }

    startAmbulanceLoop() {
        
        this.toggleAmbulances();

        
        this.loopInterval = setInterval(() => {
            this.toggleAmbulances();
        }, 2000);
    }

    toggleAmbulances() {
        if (this.showFirstAmbulance) {
            this.showFirstAmbulance = false;
            this.showSecondAmbulance = true;

            setTimeout(() => {
                this.showFirstAmbulance = true;
                this.showSecondAmbulance = false;
            }, 1000);
        }
    }

    fetchLatest() {
        getLatestShuttle()
            .then(data => {
                if (data) {
                    this.vehicleName = data.Ambulance__r?.Vehicle_Number__c || 'Not Assigned';
                    this.noteForDriver = (data.AmbulanceNotification__c || 'No instructions').replace(/\n/g, '<br/>');
                    this.shuttleId = data.Id;
                    this.toLocation = data.EC_Location__c || 'Destination';
                    this.fromLocation = data.Ambulance__r.Location__c || 'Unknown';
                    this.smartRouteText = (data.SmartRoute__c || '').replace(/\n/g, '<br/>');
    
                    setTimeout(() => {
                        const noteElement = this.template.querySelector('.driver-note-text');
                        if (noteElement) {
                            noteElement.innerHTML = this.noteForDriver;
                            noteElement.classList.add('slide-fade-in');
                        }
                        this.showActionButtons = true; 
                    }, 2000); 

                   
                    
                } else {
                    this.vehicleName = 'No Shuttle Assigned';
                    this.noteForDriver = 'No instructions';
                    this.toLocation = 'Destination';
                    this.fromLocation = 'Unknown';
                }
            })
            .catch(error => {
                this.vehicleName = 'Error fetching vehicle';
                this.noteForDriver = '';
                console.error(error);
            });
    }
    
    handleStatusUpdate(event) {
        const clicked = event.currentTarget.name;
    
        let status = '';
        if (clicked === 'accept') status = 'Accept';
        else if (clicked === 'transfer') status = 'Transfer';
        else return;
    
        updateShuttleStatus({ shuttleId: this.shuttleId, newStatus: status })
            .then(() => {
                this.hideButtonsAndNote = true;
    
                if (clicked === 'accept') {
                    this.startCountdown('accept');
    
                    setTimeout(() => {
                        const acceptButton = this.template.querySelector('.bounce-button');
                        if (acceptButton) {
                            acceptButton.classList.remove('bounce-button');
                            acceptButton.classList.add('fade-out-button');
                        }
    
                        // 🚀 Start animation and show SmartRoute
                        this.showAnimation = true;
                        this.showSmartRoute = true;
    
                        // ⏳ Wait 3 seconds, then switch to Patient Form
                        setTimeout(() => {
                            this.showSmartRoute = false;
                            this.showPatientForm = true;
                        }, 3000);
    
                        // ⌛ Safely inject SmartRoute text after render
                        setTimeout(() => {
                            const routeElement = this.template.querySelector('.driver-route-text');
                            console.log('Injecting SmartRoute:', this.smartRouteText);
                            if (routeElement) {
                                routeElement.innerHTML = this.smartRouteText;
                                routeElement.classList.add('slide-fade-in');
                            } else {
                                console.warn('driver-route-text not found at delayed injection');
                            }
                        }, 500); // Slight delay to ensure DOM is ready
                    }, 0);
                }
    
                if (clicked === 'transfer') {
                    this.fadeOutContent();
                    setTimeout(() => {
                        this.showWallpaper = true;
                        this.startCountdown('transfer');
                    }, 1000);
                }
    
                this.dispatchEvent(new ShowToastEvent({
                    title: `Marked as ${status}`,
                    message: 'Status updated.',
                    variant: 'success'
                }));
            })
            .catch(error => {
                console.error(error);
                this.dispatchEvent(new ShowToastEvent({
                    title: 'Error',
                    message: error.body?.message || 'Server Error',
                    variant: 'error'
                }));
            });
    }
    

    startCountdown(actionType) {
        this.countdown = 3;
        const intervalId = setInterval(() => {
            this.countdown--;
            if (this.countdown === 0) {
                clearInterval(intervalId);
                if (actionType === 'accept') {
                    this.showAnimation = true;
                    this.showPatientForm = true;
                    this.animateAmbulance();
                }
                if (actionType === 'transfer') {
                    
                }
            }
        }, 1000);
    }

    animateAmbulance() {
        this.showSecondAmbulance = true; 
    }

    fadeOutContent() {
        const card = this.template.querySelector('.main-card');
        if (card) {
            card.classList.add('fade-out');
        }
    }

    handleSubmitForm() {
        const patientName = this.template.querySelector('[data-field="patientName"]').value;
        const initialAssessment = this.template.querySelector('[data-field="initialAssessment"]').value;
    
        this.isSubmitting = true; 
    
        createPatientRecord({ 
            shuttleId: this.shuttleId,
            patientName: patientName,
            initialAssessment: initialAssessment 
        })
        .then(() => {
            this.dispatchEvent(new ShowToastEvent({
                title: 'Success',
                message: 'Patient created successfully!',
                variant: 'success'
            }));
            
            //this.template.querySelector('[data-field="patientName"]').value = '';
            //this.template.querySelector('[data-field="initialAssessment"]').value = '';
            setTimeout(() => {
                this.showPatientForm = false;
            }, 1000);
            setTimeout(() => {
                this.showThankYou = true;
            }, 2000);
            setTimeout(() => {
                this.showThankYou = false;
                this.showSmartRoute = true;
            }, 6000);
            setTimeout(() => {
                const routeElement = this.template.querySelector('.driver-route-text');
                if (routeElement) {
                    routeElement.innerHTML = this.smartRouteText;
                    routeElement.classList.add('slide-fade-in');
                }
            }, 6500); 
            
           
            
        })
        .catch(error => {
            console.error(error);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error creating patient',
                message: error.body?.message || 'Unknown error',
                variant: 'error'
            }));
        })
        .finally(() => {
            this.isSubmitting = false; 
        });
    }

    get submitButtonLabel() {
        return this.isSubmitting ? 'Submitting...' : 'Submit';
    }
    
    
}