import { LightningElement, track } from 'lwc';
import getLatestShuttleForHospital from '@salesforce/apex/AmbulanceShuttleController.getLatestShuttleForHospital';
import upsertPatient from '@salesforce/apex/AmbulanceShuttleController.upsertPatient';
import getPatientForShuttle from '@salesforce/apex/AmbulanceShuttleController.getPatientForShuttle';

export default class HospitalDashboard extends LightningElement {
    @track showHospitalInfo = false;
    @track shuttleRecord;

    @track showAmbulanceInfo = true;
    @track showAdmissionForm = false;
    @track showLogisticsForm = false;

    @track admissionCardClass = 'icu-box clickable';
    @track logisticsCardClass = 'icu-box clickable';

    @track isSubmitting = false;
    @track showThankYou = false;
    @track submitLabel = 'Submit';

    @track patientRecord;
    @track showPatientDetails = false;

    intervalId;

    connectedCallback() {
        this.startPolling();
    }

    disconnectedCallback() {
        clearInterval(this.intervalId);
    }

    startPolling() {
        this.isPolling = true;
        this.poll();
    }
    
    poll() {
        if (!this.isPolling) {
            return;
        }
    
        this.fetchShuttleData()
            .then(() => {
                
                setTimeout(() => {
                    this.poll();
                }, 5000);
            });
    }
    
    startPatientPolling() {
        this.patientPolling = true;
        this.pollPatientDetails();
    }
    
    pollPatientDetails() {
        if (!this.patientPolling || !this.shuttleRecord?.Id) return;
    
        getPatientForShuttle({ shuttleId: this.shuttleRecord.Id })
            .then(patient => {
                if (patient) {
                    this.patientRecord = patient;
                    this.showPatientDetails = true;
                    this.patientPolling = false; // stop polling
                } else {
                    setTimeout(() => this.pollPatientDetails(), 3000); // keep polling
                }
            })
            .catch(error => {
                console.error('Error fetching patient record:', error);
                setTimeout(() => this.pollPatientDetails(), 3000); // retry on failure
            });
    }
    

    fetchShuttleData() {
        return getLatestShuttleForHospital()
            .then(result => {
                console.log('Shuttle record received:', JSON.stringify(result, null, 2));
                if (result) {
                    console.log('Status__c:', result.Status__c);
                    console.log('Hospital__c:', result.Hospital__c);
                    if (result.Status__c && result.Status__c.trim().toLowerCase() === 'accept' && result.Hospital__c) {
                        console.log('✅ Condition satisfied, stopping polling');
                        this.shuttleRecord = result;
                        this.showHospitalInfo = true;
                        this.showAmbulanceInfo = true;
                        this.showAdmissionForm = false;
                        this.showLogisticsForm = false;
                        this.startPatientPolling();

                        this.isPolling = false; 
                    } else {
                        console.log('⏳ Condition not met yet');
                    }
                } else {
                    console.log('No shuttle record found yet.');
                }
            })
            .catch(error => {
                console.error('Error fetching shuttle record:', error);
            });
    }
    
    disconnectedCallback() {
        this.isPolling = false; 
    }
    
    handleAdmissionClick() {
        this.showAdmissionForm = true;
        this.showLogisticsForm = false;
        this.showAmbulanceInfo = false;
        this.showPatientDetails = false;
        this.admissionCardClass = 'icu-box clickable selected';
        this.logisticsCardClass = 'icu-box clickable';
    }
    
    handleLogisticsClick() {
        this.showAdmissionForm = false;
        this.showLogisticsForm = true;
        this.showAmbulanceInfo = false;
    
        this.admissionCardClass = 'icu-box clickable';
        this.logisticsCardClass = 'icu-box clickable selected';
    }

    handleSubmitForm() {
        this.isSubmitting = true;
        this.submitLabel = 'Submitting...';
        
        const patientName = this.template.querySelector('[data-field="patientName"]').value;
        const initialAssessment = this.template.querySelector('[data-field="initialAssessment"]').value;
    
        if (!patientName || !initialAssessment) {
            this.isSubmitting = false;
            this.submitLabel = 'Submit';
            alert('Please fill out both fields.');
            return;
        }
    
        const payload = {
            Name: patientName,
            Paramed_Notes__c: initialAssessment,
            Ambulance_Shuttle__c: this.shuttleRecord.Id
        };
    
        upsertPatient({ patientData: payload })
        .then(() => {
            this.isSubmitting = false;
            this.submitLabel = 'Submit';
        
            // Step 1: hide form
            setTimeout(() => {
                this.showAdmissionForm = false;
            }, 1000);
        
            // Step 2: show thank-you
            setTimeout(() => {
                this.showThankYou = true;
            }, 2000);
        
            // Step 3: return to ambulance info
            setTimeout(() => {
                this.showThankYou = false;
                this.showAmbulanceInfo = true;
                this.showPatientDetails = true;
            }, 6000);
        })
        
            .catch(error => {
                console.error('Error saving patient:', error);
                this.isSubmitting = false;
                this.submitLabel = 'Submit';
                alert('Something went wrong while saving the patient record.');
            });
    }
    
    
}